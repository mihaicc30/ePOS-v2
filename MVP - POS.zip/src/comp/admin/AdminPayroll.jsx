

const AdminPayroll = () => {
  return (
    <div className="flex flex-col">
    <p className="text-xl font-bold p-2 underline relative">
      Payroll <span className=" absolute text-xs font-light top-2">*in future development</span>
    </p>
       <div className="grow flex flex-wrap">

       <div className="widget flex-1 p-2 m-1 shadow-xl">Lorem ipsum dolor sit amet consectetur adipisicing elit. Sint atque, doloremque nulla quia officia consequatur expedita voluptates minus voluptatibus assumenda. Soluta, fugit suscipit ullam pariatur neque id est mollitia maiores!</div>

       </div>
    </div>
  )
}

export default AdminPayroll
