import React, { useState, useEffect } from "react";
import "./App.css";
import { auth, db, logout } from "./firebase/config.jsx";
import { Routes, Route, Outlet, NavLink, BrowserRouter } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

// Routes
import Layout from "./Layout";

import Admin from "./comp/admin/Admin";
import Menu from "./comp/menu/Menu";
import Auth from "./comp/auth/Auth";
import Signout from "./comp/signout/Signout";
import Page404 from "./comp/Page404";
import Settings from "./comp/settings/Settings";
import Contact from "./comp/settings/Contact";
import Notifications from "./comp/settings/Notifications";
import News from "./comp/settings/News";
import Privacy from "./comp/settings/Privacy";
import Symbol from "./comp/settings/Symbol";
import TC from "./comp/settings/T&C";
import Payment from "./comp/payment/Payment";
import Tables from "./comp/tables/Tables";
import KitchenScreen from "./comp/screens/KitchenScreen";
import BarScreen from "./comp/screens/BarScreen";

import { getVenueById } from "./utils/BasketUtils";

import { loadStripe } from "@stripe/stripe-js";
import { fetchWeeklyWeather, getTableLayout, getVenues, getMenu, fetchHoliday } from "./utils/DataTools";

const App = () => {
  //app settings
  const [lefty, setLefty] = useState(false);

  const [weeklyWeather, setWeeklyWeather] = useState(false);
  const [user, setUser] = useState(null);
  const [basketItems, setBasketItems] = useState([]);
  const [venueNtable, setVenueNtable] = useState({ venue: 101010, table: null });
  const [weeklyholiday, setWeeklyHoliday] = useState(false);

  const [tables, setTables] = useState([]);
  const [draggingIndex, setDraggingIndex] = useState(null);
  const [showArea, setshowArea] = useState("Bar");
  const [uniqueAreas, setuniqueAreas] = useState([]);

  const [menuitems, setMenuitems] = useState([]);
  const [venues, setVenues] = useState([]);
  const [searchValue, setSearchValue] = useState("");
  const [basketQty, setBasketQty] = useState(0);
  const [basketDiscount, setBasketDiscount] = useState(0);

  const [weeklyForecast, setWeeklyForecast] = useState({
    0: {
      date: `${String(new Date().toLocaleDateString("en-GB")).split("/")[2]}-${String(new Date().toLocaleDateString("en-GB")).split("/")[1]}-${String(new Date().toLocaleDateString("en-GB")).split("/")[0]}`,
    },
    1: null,
    2: null,
    3: null,
    4: null,
    5: null,
    6: null,
  });

  const [apiData, setApiData] = useState({
    weather: false,
    holiday: false,
    menu: false,
    venues: false,
    tableLayout: false,
    forecast: false,
  });

  const [fetchFailed, setFetchFailed] = useState(false);

  const getAsyncData = async () => {
    try {
      setWeeklyWeather(await fetchWeeklyWeather());
      setApiData((prevData) => ({ ...prevData, weather: true }));

      setWeeklyHoliday(await fetchHoliday());
      setApiData((prevData) => ({ ...prevData, holiday: true }));

      setMenuitems(await getMenu());
      setApiData((prevData) => ({ ...prevData, menu: true }));

      setVenues(await getVenues());
      setApiData((prevData) => ({ ...prevData, venues: true }));

      setTables(await getTableLayout());
      setApiData((prevData) => ({ ...prevData, tableLayout: true }));

      await fetchForecastWeek();
      setApiData((prevData) => ({ ...prevData, forecast: true }));

      setFetchFailed(false);
    } catch (error) {
      setFetchFailed(true);
      setTimeout(getAsyncData, 1000); // Retry after 1 seconds
    }
  };
  useEffect(() => {
    localStorage.setItem("venueID", 101010);

    getAsyncData();
  }, []);

  useEffect(() => {
    // Handle fetch failure
    if (fetchFailed) {
      setTimeout(getAsyncData, 1000); // Retry after 1 seconds
    }
  }, [fetchFailed]);

  useEffect(() => {
    console.log(Object.values(apiData).includes(false));
  }, [apiData]);

  useEffect(() => {
    setTimeout(async () => {
      await fetchForecastWeek();
    }, 1000);
  }, [weeklyWeather]);

  useEffect(() => {
    if (!tables || tables.length < 1) return;
    setuniqueAreas([...new Set(tables.gridSize.map((table) => table[0]))]);
  }, [tables]);

  useEffect(() => {
    calculateTotalQuantity();
  }, [basketItems]);

  const calculateTotalQuantity = () => {
    const totalQty = basketItems.reduce((total, item) => total + parseInt(item.qty), 0);
    setBasketQty(totalQty);
  };

  const fetchForecastWeek = async () => {
    if (!weeklyWeather) return;
    console.log("Received weather data. Fetching sales forecast.", new Date().toLocaleTimeString("en-GB"));
    for (let n = 0; n < 7; n++) {
      let dayt = (new Date().getDay() + n) % 7;

      setTimeout(async () => {
        let tempz = {
          cloudy: weeklyWeather.days[n]?.cloudcover || parseInt(Math.random() * (99 - 1) + 1),
          humidity: weeklyWeather.days[n]?.humidity || parseInt(Math.random() * (99 - 1) + 1),
          windspeed: weeklyWeather.days[n]?.windspeed || parseInt(Math.random() * (99 - 1) + 1),
          temp: weeklyWeather.days[n]?.temp || parseInt(Math.random() * (44 - 1) + 1),
          daytype: dayt,
          isholiday: weeklyholiday[`${n}`]?.title ? 1 : 0,
        };
        // console.log(`calling forecast api with this data:`, tempz);
        try {
          const currentDate = new Date();
          currentDate.setDate(currentDate.getDate() + n);
          const year = currentDate.getFullYear();
          const month = String(currentDate.getMonth() + 1).padStart(2, "0");
          const day = String(currentDate.getDate()).padStart(2, "0");

          const response = await fetch(`${import.meta.env.VITE_API}forecast-quick`, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "Access-Control-Allow-Credentials": true,
            },
            body: JSON.stringify({
              date: currentDate.toLocaleDateString("en-GB"),
              cloudy: weeklyWeather.days[n]?.cloudcover || parseInt(Math.random() * (99 - 1) + 1),
              humidity: weeklyWeather.days[n]?.humidity || parseInt(Math.random() * (99 - 1) + 1),
              windspeed: weeklyWeather.days[n]?.windspeed || parseInt(Math.random() * (99 - 1) + 1),
              temp: weeklyWeather.days[n]?.temp || parseInt(Math.random() * (44 - 1) + 1),
              daytype: dayt,
              isholiday: weeklyholiday[`${n}`]?.title ? 1 : 0,
              venueID: localStorage.getItem("venueID"),
              forceRefresh: localStorage.getItem("refreshForecast"),
            }),
          });
          const data = await response.json();

          setWeeklyForecast((prevState) => ({
            ...prevState,
            [n]: { date: `${year}-${month}-${day}`, average: data.average },
          }));
          localStorage.removeItem("refreshForecast");
        } catch (error) {
          localStorage.removeItem("refreshForecast");
          console.error("Error fetching weather:", error);
        }
      }, 500);
    }
  };

  return (
    <Routes>
      <Route path="/" element={<Layout weeklyholiday={weeklyholiday} weeklyForecast={weeklyForecast} weeklyWeather={weeklyWeather} setWeeklyWeather={setWeeklyWeather} setWeeklyForecast={setWeeklyForecast} lefty={lefty} setLefty={setLefty} />}>
        <Route path="/" element={<Auth apiData={apiData}/>} />

        <Route
          path="/admin/*"
          element={<Admin weeklyholiday={weeklyholiday} setWeeklyHoliday={setWeeklyHoliday} weeklyWeather={weeklyWeather} setWeeklyWeather={setWeeklyWeather} weeklyForecast={weeklyForecast} setWeeklyForecast={setWeeklyForecast} menuitems={menuitems} setMenuitems={setMenuitems} tables={tables} setTables={setTables} draggingIndex={draggingIndex} setDraggingIndex={setDraggingIndex} showArea={showArea} setshowArea={setshowArea} uniqueAreas={uniqueAreas} setuniqueAreas={setuniqueAreas} venues={venues} venueNtable={venueNtable} setVenueNtable={setVenueNtable} />}
        />

        <Route path="/kitchen" element={<KitchenScreen venueNtable={venueNtable} />}></Route>
        <Route path="/bar" element={<BarScreen venueNtable={venueNtable} />}></Route>

        <Route path="/tables" element={<Tables setBasketDiscount={setBasketDiscount} basketItems={basketItems} setBasketItems={setBasketItems} tables={tables} setTables={setTables} draggingIndex={draggingIndex} setDraggingIndex={setDraggingIndex} showArea={showArea} setshowArea={setshowArea} uniqueAreas={uniqueAreas} setuniqueAreas={setuniqueAreas} venues={venues} venueNtable={venueNtable} setVenueNtable={setVenueNtable} />} />

        <Route path="/menu" element={<Menu showArea={showArea} setshowArea={setshowArea} uniqueAreas={uniqueAreas} setuniqueAreas={setuniqueAreas} setTables={setTables} tables={tables} lefty={lefty} draggingIndex={draggingIndex} setDraggingIndex={setDraggingIndex} basketDiscount={basketDiscount} setBasketDiscount={setBasketDiscount} basketItems={basketItems} setBasketItems={setBasketItems} menuitems={menuitems} searchValue={searchValue} setSearchValue={setSearchValue} venueNtable={venueNtable} setVenueNtable={setVenueNtable} venues={venues} />}></Route>

        <Route path="/payment" element={<Payment lefty={lefty} basketDiscount={basketDiscount} setVenueNtable={setVenueNtable} venueNtable={venueNtable} basketItems={basketItems} setBasketItems={setBasketItems} user={user} />} />

        <Route path="/settings" element={<Settings venues={venues} />} />

        <Route path="/contact" element={<Contact />} />
        <Route path="/notifications" element={<Notifications />} />
        <Route path="/news" element={<News />} />
        <Route path="/privacy" element={<Privacy />} />
        <Route path="/symbol" element={<Symbol />} />
        <Route path="/t&c" element={<TC />} />

        <Route path="/signout" element={<Signout setUser={setUser} setVenueNtable={setVenueNtable} venueNtable={venueNtable} />} />

        <Route path="*" element={<Page404 />} />
      </Route>
    </Routes>
  );
};

export default App;
